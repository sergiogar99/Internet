package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ConexionDB.ConexionDB;
import model.Fichero;

public class FicheroDAOImpl implements FicheroDAO {
    @Override
    public void agregarFichero(Fichero fichero) {
        String sql = "INSERT INTO Ficheros (titulo, ruta, idActividad) VALUES (?, ?, ?)";

        try (Connection connection = ConexionDB.obtenerConexion();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, fichero.getTitulo());
            statement.setString(2, fichero.getRuta());
            statement.setInt(3, fichero.getIdActividad());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

