package ConexionDB;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class ConexionDB {

	public static Connection obtenerConexion() throws SQLException {
	    try {
	        // Obtiene el contexto inicial sin el prefijo java:comp/env
	        Context initialContext = new InitialContext();

	        // El nombre JNDI del recurso JDBC configurado en Glassfish
	        // Se asume que este nombre JNDI está enlazado en el contexto global del servidor de aplicaciones
	        String jndiName = "jdbc/actividades_1";
	        
	        // Busca directamente el DataSource sin pasar por java:comp/env
	        DataSource dataSource = (DataSource) initialContext.lookup(jndiName);
	        
	        if (dataSource == null) {
	            throw new SQLException("No se encontró el recurso JDBC: " + jndiName);
	        }
	        
	        return dataSource.getConnection();
	    } catch (NamingException e) {
	        throw new SQLException("Error al obtener la conexión: " + e.getMessage(), e);
	    }
	}

}

