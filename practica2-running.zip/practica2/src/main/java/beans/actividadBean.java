package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.servlet.http.Part;
import java.util.List;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import javax.faces.context.FacesContext;
import javax.faces.context.ExternalContext;
import java.io.IOException;
import java.util.Date;

import model.actividad;
import model.comentario;
import model.fichero;
import model.participacion;
import model.usuario;
import model.votacion;

import java.util.List;

@ManagedBean
@ViewScoped
public class actividadBean {
    @PersistenceContext(unitName = "tuUnidadDePersistencia")
    private EntityManager em;
	private Part file;

    public Part getFile() {
        return file;
    }

    public void setFile(Part file) {
        this.file = file;
    }

    public List<actividad> getActividades() {
        return em.createQuery("SELECT a FROM Actividad a", actividad.class).getResultList();
    }

    @Transactional
	public String inscribirEnActividad(Long actividadId, usuario usuario) {
		actividad actividad = em.find(actividad.class, actividadId);
		long count = (long) em.createQuery("SELECT COUNT(p) FROM Participacion p WHERE p.actividad.id = :actividadId")
                          .setParameter("actividadId", actividadId)
                          .getSingleResult();
		if (count < 20) { // Suponiendo un máximo de 20 participantes
			participacion participacion = new participacion(usuario, actividad, new Date()); // Asumiendo constructor adecuado
			em.persist(participacion);
			return "inscripcionExitosa";
		} else {
			return "actividadCompleta";
		}
	}

	public List<actividad> actividadesInscritas(usuario usuario) {
    return em.createQuery("SELECT p.actividad FROM Participacion p WHERE p.usuario = :usuario", actividad.class)
             .setParameter("usuario", usuario)
             .getResultList();
	}
	
	@Transactional
	public String cancelarInscripcion(Long participacionId) {
		participacion participacion = em.find(participacion.class, participacionId);
		if (participacion != null) {
			actividad actividad = participacion.getActividad();
			actividad.setCuposDisponibles(actividad.getCuposDisponibles() + 1); // Incrementar cupos disponibles
			em.remove(participacion); // Eliminar la participación
			return "cancelacionExitosa"; // Redirigir a una vista de éxito
		} else {
			return "errorCancelacion"; // Redirigir a una vista de error
		}
	}


    @Transactional
    public void votar(Long actividadId, usuario usuario, int puntuacion) {
    	votacion votacion = new votacion();
        votacion.setUsuario(usuario);
        votacion.setActividad(em.find(actividad.class, actividadId));
        votacion.setPuntuacion(puntuacion);
        em.persist(votacion);
        // Actualizar promedio de votos de la actividad si es necesario
    }

    @Transactional
    public void comentar(Long actividadId, usuario usuario, String texto) {
    	comentario comentario = new comentario();
        comentario.setUsuario(usuario);
        comentario.setActividad(em.find(actividad.class, actividadId));
        comentario.setTexto(texto);
        em.persist(comentario);
        // Agregar el comentario a la lista de comentarios de la actividad
    }
	
	public void subirFichero() {
        // Suponiendo una carpeta 'uploads' en el servidor donde se guardarán los ficheros
        try (InputStream input = file.getInputStream()) {
            Files.copy(input, Paths.get("/uploads", file.getSubmittedFileName()), StandardCopyOption.REPLACE_EXISTING);
            // Guardar la referencia del fichero en la base de datos si es necesario
        } catch (Exception e) {
            // Manejo de excepciones
        }
    }

    public void descargarFichero(Long ficheroId) throws IOException {
		fichero fichero = em.find(fichero.class, ficheroId);
		if (fichero != null) {
			FacesContext fc = FacesContext.getCurrentInstance();
			ExternalContext ec = fc.getExternalContext();

			ec.responseReset(); 
			ec.setResponseContentType(fichero.getTipo()); 
			ec.setResponseContentLength(fichero.getTamano().intValue()); 
			ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + fichero.getNombre() + "\"");

			OutputStream output = ec.getResponseOutputStream();
			output.write(fichero.getContenido());
			output.flush();
			output.close();

			fc.responseComplete(); 
		}
	}

}
