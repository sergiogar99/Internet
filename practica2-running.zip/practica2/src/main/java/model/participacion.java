package model;
import javax.persistence.*;
import java.util.Date;

@Entity
public class participacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private usuario usuario;

    @ManyToOne
    @JoinColumn(name = "actividad_id")
    private actividad actividad;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaInscripcion;

    // Constructor vacío requerido por JPA
    public participacion() {}

    // Constructor para facilitar la creacion de Participacion
    public participacion(usuario usuario, actividad actividad, Date fechaInscripcion) {
        this.usuario = usuario;
        this.actividad = actividad;
        this.fechaInscripcion = fechaInscripcion;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public usuario getUsuario() { return usuario; }
    public void setUsuario(usuario usuario) { this.usuario = usuario; }
    public actividad getActividad() { return actividad; }
    public void setActividad(actividad actividad) { this.actividad = actividad; }
    public Date getFechaInscripcion() { return fechaInscripcion; }
    public void setFechaInscripcion(Date fechaInscripcion) { this.fechaInscripcion = fechaInscripcion; }
}
