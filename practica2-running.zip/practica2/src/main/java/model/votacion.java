package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexion.ConexionDB;

public class votacion {

    private int id;
    private int puntuacion; // Cambio de 'valoracion' a 'puntuacion'
    private usuario usuario; // Cambio de 'idUsuario' a 'usuario' y uso de tipo Usuario
    private actividad actividad; // 

    // Constructor
    public votacion() {

    }

    // Getters y Setters actualizados para Long
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(usuario usuario) {
        this.usuario = usuario;
    }

    public actividad getActividad() {
        return actividad;
    }

    public void setActividad(actividad actividad) {
        this.actividad = actividad;
    }

    public void guardar() {
        String sql = "INSERT INTO votaciones (puntuacion, usuario, actividad) VALUES (?, ?, ?)";

        try (Connection conn = ConexionDB.obtenerConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, this.puntuacion);
            pstmt.setLong(2, this.usuario.getId());
            pstmt.setLong(3, this.actividad.getId());

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
