package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexion.ConexionDB;

// Cambiando el nombre de la clase a "Comentario" para seguir las convenciones de Java
public class comentario {

    private int id;
    private String contenido;
    private usuario usuario; // Usando la clase Usuario en lugar de int idUsuario
    private actividad actividad; // Usando la clase Actividad en lugar de int idActividad

    // Constructor actualizado
    public comentario() {

    }

    // Getters y Setters actualizados
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContenido() {
        return contenido;
    }

    public void setTexto(String texto) {
        this.contenido = texto;
    }

    public usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(usuario usuario) {
        this.usuario = usuario;
    }

    public actividad getActividad() {
        return actividad;
    }

    public void setActividad(actividad actividad) {
        this.actividad = actividad;
    }

    // Metodo para interactuar con la base de datos
    public void guardar() {
        String sql = "INSERT INTO comentarios (contenido, idUsuario, idActividad) VALUES (?, ?, ?)";

        try (Connection conn = ConexionDB.obtenerConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, this.contenido);
            pstmt.setLong(2, this.usuario.getId());
            pstmt.setLong(3, this.actividad.getId());

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Otros metodos relacionados con la logica de negocio
}
