package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.UsuarioDAO;
import DAO.UsuarioDAOImpl;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UsuarioDAO usuarioDao = new UsuarioDAOImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (usuarioDao.validarCredenciales(username, password)) {
            //Credenciales válidas, redirigir a la ventana de gestión de actividades
            response.sendRedirect("ActividadesServlet");
        } else {
            //Credenciales inválidas, redirigir de nuevo a la página de inicio de sesión
            response.sendRedirect("index.jsp");
        }
    }
}


