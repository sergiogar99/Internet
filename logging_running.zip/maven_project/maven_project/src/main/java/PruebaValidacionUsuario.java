
import DAO.UsuarioDAO;
import DAO.UsuarioDAOImpl;

public class PruebaValidacionUsuario {

    public static void main(String[] args) {
        // Crear una instancia del DAO
        UsuarioDAO usuarioDao = new UsuarioDAOImpl();

        // Definir las credenciales para probar
        String username = "user"; // Cambiar por un usuario real de tu DB
        String password = "123"; // Cambiar por la contraseña real del usuario

        // Llamar al método validarCredenciales y imprimir el resultado
        boolean esValido = usuarioDao.validarCredenciales(username, password);

        if (esValido) {
            System.out.println("Las credenciales son válidas.");
        } else {
            System.out.println("Las credenciales son inválidas.");
        }
    }
}
