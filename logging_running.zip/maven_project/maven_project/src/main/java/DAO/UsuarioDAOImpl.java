package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ConexionDB.ConexionDB;

public class UsuarioDAOImpl implements UsuarioDAO {
	    @Override
	    public boolean validarCredenciales(String usuario, String contraseña) {
	        String sql = "SELECT * FROM Usuarios WHERE login = ? AND password = ?";

	        try (Connection connection = ConexionDB.obtenerConexion();
	             PreparedStatement statement = connection.prepareStatement(sql)) {

	            statement.setString(1, usuario);
	            statement.setString(2, contraseña);

	            try (ResultSet resultSet = statement.executeQuery()) {
	                return resultSet.next();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return false;
	    }
}

