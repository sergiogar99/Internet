package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ConexionDB.ConexionDB;
import model.Actividad;

public class ActividadDAOImpl implements ActividadDAO {
    @Override
    public List<Actividad> obtenerTodasLasActividades() {
        List<Actividad> actividades = new ArrayList<>();
        String sql = "SELECT * FROM Actividades";

        try (Connection connection = ConexionDB.obtenerConexion();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Actividad actividad = new Actividad();
                actividad.setId(resultSet.getInt("id"));
                actividad.setTitulo(resultSet.getString("titulo"));
                actividad.setDescripcion(resultSet.getString("descripcion"));
                actividad.setRecomendaciones(resultSet.getString("recomendaciones"));
                actividad.setDocentes(resultSet.getString("docentes"));
                actividad.setDias(resultSet.getString("dias"));
                actividad.setHorario(resultSet.getString("horario"));
                actividad.setFechaInicio(resultSet.getDate("fechaInicio"));
                actividad.setFechaFin(resultSet.getDate("fechaFin"));

                actividades.add(actividad);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return actividades;
    }
    
    @Override
    public void guardarActividad(Actividad actividad) {
        String sql = "INSERT INTO Actividades (titulo, descripcion, ...) VALUES (?, ?, ...)";

        try (Connection connection = ConexionDB.obtenerConexion();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, actividad.getTitulo());
            statement.setString(2, actividad.getDescripcion());
            // Establece otros campos según sea necesario

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	@Override
	public Actividad obtenerActividadPorId(int idActividad) {
		// TODO Auto-generated method stub
		return null;
	}
}

