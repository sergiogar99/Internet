import javax.persistence.*;
import java.util.Date;

@Entity
public class Participacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "actividad_id")
    private Actividad actividad;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaInscripcion;

    // Constructor vacío requerido por JPA
    public Participacion() {}

    // Constructor para facilitar la creación de Participacion
    public Participacion(Usuario usuario, Actividad actividad, Date fechaInscripcion) {
        this.usuario = usuario;
        this.actividad = actividad;
        this.fechaInscripcion = fechaInscripcion;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public Actividad getActividad() { return actividad; }
    public void setActividad(Actividad actividad) { this.actividad = actividad; }
    public Date getFechaInscripcion() { return fechaInscripcion; }
    public void setFechaInscripcion(Date fechaInscripcion) { this.fechaInscripcion = fechaInscripcion; }
}
