@Entity
public class Fichero {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String tipo;
    private Long tamano;
    
    @Lob
    private byte[] contenido;

    // Constructor vacío requerido por JPA
    public Fichero() {}

    // Constructor completo podría ser útil para la creación de objetos
    public Fichero(String nombre, String tipo, Long tamano, byte[] contenido) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.tamano = tamano;
        this.contenido = contenido;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public Long getTamano() { return tamano; }
    public void setTamano(Long tamano) { this.tamano = tamano; }
    public byte[] getContenido() { return contenido; }
    public void setContenido(byte[] contenido) { this.contenido = contenido; }
}
