import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@ManagedBean
@ViewScoped
public class ActividadBean {
    @PersistenceContext(unitName = "tuUnidadDePersistencia")
    private EntityManager em;
	private Part file;

    public Part getFile() {
        return file;
    }

    public void setFile(Part file) {
        this.file = file;
    }

    public List<Actividad> getActividades() {
        return em.createQuery("SELECT a FROM Actividad a", Actividad.class).getResultList();
    }

    @Transactional
	public String inscribirEnActividad(Long actividadId, Usuario usuario) {
		Actividad actividad = em.find(Actividad.class, actividadId);
		long count = (long) em.createQuery("SELECT COUNT(p) FROM Participacion p WHERE p.actividad.id = :actividadId")
                          .setParameter("actividadId", actividadId)
                          .getSingleResult();
		if (count < 20) { // Suponiendo un máximo de 20 participantes
			Participacion participacion = new Participacion(usuario, actividad, new Date()); // Asumiendo constructor adecuado
			em.persist(participacion);
			return "inscripcionExitosa";
		} else {
			return "actividadCompleta";
		}
	}

	public List<Actividad> actividadesInscritas(Usuario usuario) {
    return em.createQuery("SELECT p.actividad FROM Participacion p WHERE p.usuario = :usuario", Actividad.class)
             .setParameter("usuario", usuario)
             .getResultList();
	}
	
	@Transactional
	public String cancelarInscripcion(Long participacionId) {
		Participacion participacion = em.find(Participacion.class, participacionId);
		if (participacion != null) {
			Actividad actividad = participacion.getActividad();
			actividad.setCuposDisponibles(actividad.getCuposDisponibles() + 1); // Incrementar cupos disponibles
			em.remove(participacion); // Eliminar la participación
			return "cancelacionExitosa"; // Redirigir a una vista de éxito
		} else {
			return "errorCancelacion"; // Redirigir a una vista de error
		}
	}


    @Transactional
    public void votar(Long actividadId, Usuario usuario, int puntuacion) {
        Votacion votacion = new Votacion();
        votacion.setUsuario(usuario);
        votacion.setActividad(em.find(Actividad.class, actividadId));
        votacion.setPuntuacion(puntuacion);
        em.persist(votacion);
        // Actualizar promedio de votos de la actividad si es necesario
    }

    @Transactional
    public void comentar(Long actividadId, Usuario usuario, String texto) {
        Comentario comentario = new Comentario();
        comentario.setUsuario(usuario);
        comentario.setActividad(em.find(Actividad.class, actividadId));
        comentario.setTexto(texto);
        em.persist(comentario);
        // Agregar el comentario a la lista de comentarios de la actividad
    }
	
	public void subirFichero() {
        // Suponiendo una carpeta 'uploads' en el servidor donde se guardarán los ficheros
        try (InputStream input = file.getInputStream()) {
            Files.copy(input, Paths.get("/uploads", file.getSubmittedFileName()), StandardCopyOption.REPLACE_EXISTING);
            // Guardar la referencia del fichero en la base de datos si es necesario
        } catch (Exception e) {
            // Manejo de excepciones
        }
    }

    public void descargarFichero(Long ficheroId) throws IOException {
		Fichero fichero = em.find(Fichero.class, ficheroId);
		if (fichero != null) {
			FacesContext fc = FacesContext.getCurrentInstance();
			ExternalContext ec = fc.getExternalContext();

			ec.responseReset(); 
			ec.setResponseContentType(fichero.getTipo()); 
			ec.setResponseContentLength(fichero.getTamano().intValue()); 
			ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + fichero.getNombre() + "\"");

			OutputStream output = ec.getResponseOutputStream();
			output.write(fichero.getContenido());
			output.flush();
			output.close();

			fc.responseComplete(); 
		}
	}

}
