import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@ManagedBean(name = "loginBean")
@SessionScoped
public class LoginBean {

    private String username;
    private String password;

    @PersistenceContext(unitName = "tuUnidadDePersistencia")
    private EntityManager em;

    public String validateUser() {
        TypedQuery<Usuario> query = em.createQuery("SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password", Usuario.class);
        query.setParameter("username", this.username);
        query.setParameter("password", this.password);
        try {
            Usuario user = query.getSingleResult();
            return "home"; // Navegar a la página de inicio si el usuario es válido
        } catch (Exception e) {
            return "login"; // Mantener en la página de login si las credenciales son incorrectas
        }
    }

    // Getters y Setters
}
