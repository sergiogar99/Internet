package app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    private Connection connection;

    public UsuarioDAO(Connection connection) {
        this.connection = connection;
    }

    public Usuario buscarPorNombreUsuario(String nombreUsuario) throws SQLException {
        Usuario usuario = null;
        String sql = "SELECT * FROM usuarios WHERE login = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, nombreUsuario);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    usuario = new Usuario();
                    usuario.setId(resultSet.getInt("id"));
                    usuario.setNombreUsuario(resultSet.getString("login"));
                    usuario.setContrasena(resultSet.getString("contrasena"));
                    // Otros campos seg�n la estructura de tu tabla de usuarios
                }
            }
        }

        return usuario;
    }
}