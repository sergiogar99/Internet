package app;

import java.util.List;

public class ActivityService {

  private List<Activity> activities;

  public ActivityService() {
    activities = new ArrayList<>();
    activities.add(new Activity("Yoga", "Ejercicios de yoga"));
    activities.add(new Activity("Pilates", "Ejercicios de pilates"));
    activities.add(new Activity("Cardio", "Ejercicios cardiovasculares"));
  }

  public List<Activity> getActivities() {
    return activities;
  }

  public void addActivity(Activity activity) {
    activities.add(activity);
  }

  public void deleteActivity(Activity activity) {
    activities.remove(activity);
  }

}