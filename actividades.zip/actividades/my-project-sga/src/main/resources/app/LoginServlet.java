package app;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String JDBC_RESOURCE_NAME = "jdbc/Test";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombreUsuario = request.getParameter("nombreUsuario");
        String contrasena = request.getParameter("contrasena");

        DataSource dataSource = (DataSource) new InitialContext().lookup(JDBC_RESOURCE_NAME);
        try (Connection connection = dataSource.getConnection()) {
            UsuarioDAO usuarioDAO = new UsuarioDAO(connection);
            
            // Modifica el m�todo buscarPorNombreUsuario para que realice la consulta en la tabla de usuarios
            Usuario usuario = usuarioDAO.buscarPorNombreUsuario(nombreUsuario);

            if (usuario != null) {
                if (usuario.getContrasena().equals(contrasena)) {
                    response.sendRedirect("index.jsp");
                } else {
                    request.setAttribute("error", "Contrase�a incorrecta.");
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("error", "Nombre de usuario o contrase�a incorrectos.");
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}