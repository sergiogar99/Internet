-- Dentro de la base de datos gym
USE gym;

-- Tabla Usuarios
CREATE TABLE Usuarios (
  id INT NOT NULL AUTO_INCREMENT,
  login VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  perfilAcceso VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

-- Tabla Actividades
CREATE TABLE Actividades (
  id INT NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(255) NOT NULL,
  descripcion TEXT NOT NULL,
  recomendaciones TEXT NOT NULL,
  docentes VARCHAR(255) NOT NULL,
  dias VARCHAR(255) NOT NULL,
  horario VARCHAR(255) NOT NULL,
  fechaInicio DATE NOT NULL,
  fechaFin DATE NOT NULL,
  PRIMARY KEY (id)
);

-- Tabla Ficheros
CREATE TABLE Ficheros (
  id INT NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(255) NOT NULL,
  ruta VARCHAR(255) NOT NULL,
  idActividad INT NOT NULL,
  PRIMARY KEY (id),
  FOREIGN KEY (idActividad) REFERENCES Actividades (id)
);
