package DAO;

import model.Fichero;

public interface FicheroDAO {
    void agregarFichero(Fichero fichero);
}


