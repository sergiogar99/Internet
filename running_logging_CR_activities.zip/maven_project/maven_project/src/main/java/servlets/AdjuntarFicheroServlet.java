package servlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.apache.commons.io.IOUtils;


import DAO.FicheroDAO;
import DAO.FicheroDAOImpl;
import model.Fichero;

@MultipartConfig
public class AdjuntarFicheroServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private FicheroDAO ficheroDao = new FicheroDAOImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Obtenemos el ID de la actividad al que se asociará el fichero
        int idActividad = Integer.parseInt(request.getParameter("idActividad"));

        //OBtenemos el título del fichero
        String titulo = request.getParameter("titulo");

        //Obtenemos el fichero adjunto desde la solicitud
        Part part = request.getPart("archivo");
        InputStream inputStream = part.getInputStream();

        //Guardamos fichero en bbdd
        String rutaAlmacenamiento = guardarFicheroEnSistemaArchivos(inputStream, titulo, idActividad);

        Fichero fichero = new Fichero();
        fichero.setTitulo(titulo);
        fichero.setRuta(rutaAlmacenamiento);
        fichero.setIdActividad(idActividad);

        //Guarda la información del fichero en la base de datos
        ficheroDao.agregarFichero(fichero);

        //Redirige a la página de detalle de la actividad
        response.sendRedirect("DetalleActividadServlet?id=" + idActividad);
    }

    private String guardarFicheroEnSistemaArchivos(InputStream inputStream, String titulo, int idActividad) {
        //Implementamos logica para guardar fichero en bbdd

        String directorioBase = "ruta/a/tu/directorio/base";
        String nombreArchivo = titulo + "_" + idActividad + ".txt";

        try {
            OutputStream outputStream = new FileOutputStream(new File(directorioBase, nombreArchivo));
            IOUtils.copy(inputStream, outputStream);
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return directorioBase + "/" + nombreArchivo;
    }
}
