package model;

public class Fichero {
    private int id;
    private String titulo;
    private String ruta;
    private int idActividad;

    public Fichero(){}
    
    public Fichero(int id, String titulo, String ruta, int idActividad) {
        this.id = id;
        this.titulo = titulo;
        this.ruta = ruta;
        this.idActividad = idActividad;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public int getIdActividad() {
        return idActividad;
    }

    public void setIdActividad(int idActividad) {
        this.idActividad = idActividad;
    }

    @Override
    public String toString() {
        return "Fichero{id=" + id + ", titulo='" + titulo + "', ruta='" + ruta + "', idActividad=" + idActividad + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Fichero fichero = (Fichero) obj;
        return id == fichero.id;
    }
}






