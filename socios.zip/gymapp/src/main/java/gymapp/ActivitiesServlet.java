package gymapp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/activities")
public class ActivitiesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String usuarioLogin = (String) session.getAttribute("user");

        try (Connection connection = DBConnection.getConnection()) {
            List<Activity> activities = new ArrayList<>();
            List<Integer> participatedActivities = new ArrayList<>();

            String sqlActivities = "SELECT * FROM Actividades";
            try (PreparedStatement statement = connection.prepareStatement(sqlActivities)) {
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    Activity activity = new Activity();
                    activity.setId(resultSet.getInt("id"));
                    activity.setTitle(resultSet.getString("titulo"));
                    activity.setDescription(resultSet.getString("descripcion"));
                    activity.setRecomendaciones(resultSet.getString("recomendaciones"));
                    activity.setDocentes(resultSet.getString("docentes"));
                    activity.setDias(resultSet.getString("dias"));
                    activity.setHorario(resultSet.getString("horario"));
                    activity.setFechaInicio(resultSet.getDate("fechaInicio"));
                    activity.setFechaFin(resultSet.getDate("fechaFin"));
                    activities.add(activity);
                }
            }

            int idUsuario = 0;
            String sqlUserId = "SELECT id FROM Usuarios WHERE login = ?";
            try (PreparedStatement statement = connection.prepareStatement(sqlUserId)) {
                statement.setString(1, usuarioLogin);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    idUsuario = resultSet.getInt("id");
                }
            }

            String sqlParticipations = "SELECT idActividad FROM Participaciones WHERE idUsuario = ?";
            try (PreparedStatement statement = connection.prepareStatement(sqlParticipations)) {
                statement.setInt(1, idUsuario);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    participatedActivities.add(resultSet.getInt("idActividad"));
                }
            }

            request.setAttribute("activities", activities);
            request.setAttribute("participatedActivities", participatedActivities);
            request.getRequestDispatcher("/activities.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error al recuperar las actividades", e);
        }
    }
}
