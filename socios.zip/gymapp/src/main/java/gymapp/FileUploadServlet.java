package gymapp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.nio.file.*;
import java.sql.*;

@WebServlet("/uploadServlet")
@MultipartConfig
public class FileUploadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String usuarioLogin = (String) session.getAttribute("user");
        int userId = 0;

        int activityId = Integer.parseInt(request.getParameter("activityId"));
        String fileTitle = request.getParameter("fileTitle");
        Part filePart = request.getPart("file"); // Obtiene el archivo

        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
        String directoryPath = getServletContext().getRealPath("/") + "directorio/" + activityId;

        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String filePath = directoryPath + File.separator + fileName;
        filePart.write(filePath);

        try (Connection connection = DBConnection.getConnection()) {
            String sqlUser = "SELECT id FROM Usuarios WHERE login = ?";
            try (PreparedStatement statement = connection.prepareStatement(sqlUser)) {
                statement.setString(1, usuarioLogin);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    userId = resultSet.getInt("id");
                }
            }

            String sqlFile = "INSERT INTO Ficheros (titulo, ruta, idActividad, idUsuario) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sqlFile)) {
                statement.setString(1, fileTitle);
                statement.setString(2, filePath);
                statement.setInt(3, activityId);
                statement.setInt(4, userId);
                
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            throw new ServletException("Error al guardar los detalles del archivo en la base de datos", e);
        }

        response.sendRedirect("activities");
    }
}
