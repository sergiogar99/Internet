package gymapp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int fileId = Integer.parseInt(request.getParameter("fileId"));

        try (Connection connection = DBConnection.getConnection()) {
            String sql = "SELECT titulo, ruta FROM Ficheros WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, fileId);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    String filename = resultSet.getString("titulo");
                    String filepath = resultSet.getString("ruta");

                    response.setContentType("application/octet-stream");
                    response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

                    try (InputStream in = getServletContext().getResourceAsStream(filepath);
                         OutputStream out = response.getOutputStream()) {

                        byte[] buffer = new byte[1024];
                        int numBytesRead;
                        while ((numBytesRead = in.read(buffer)) > 0) {
                            out.write(buffer, 0, numBytesRead);
                        }
                    }
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "File not found");
                }
            }
        } catch (SQLException e) {
            throw new ServletException("Database access error", e);
        }
    }
}
