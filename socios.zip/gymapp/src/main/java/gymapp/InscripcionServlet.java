package gymapp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/inscrip")
public class InscripcionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int actividadId = Integer.parseInt(request.getParameter("activityId"));
        String modoPago = request.getParameter("modoPago");
        String sugerencias = request.getParameter("sugerencias");
        HttpSession session = request.getSession();
        String usuarioLogin = (String) session.getAttribute("user");

        try (Connection connection = DBConnection.getConnection()) {
            String inscritosSql = "SELECT COUNT(*) AS inscritos FROM Participaciones WHERE idActividad = ?";
            try (PreparedStatement inscritosStatement = connection.prepareStatement(inscritosSql)) {
                inscritosStatement.setInt(1, actividadId);
                ResultSet inscritosResult = inscritosStatement.executeQuery();

                if (inscritosResult.next()) {
                    int inscritos = inscritosResult.getInt("inscritos");

                    if (inscritos < 20) {
                        String inscripcionSql = "INSERT INTO Participaciones (idActividad, idUsuario, modoPago, sugerencia) VALUES (?, (SELECT id FROM Usuarios WHERE login = ?), ?, ?)";
                        try (PreparedStatement statement = connection.prepareStatement(inscripcionSql)) {
                            statement.setInt(1, actividadId);
                            statement.setString(2, usuarioLogin);
                            statement.setString(3, modoPago);
                            statement.setString(4, sugerencias);
                            statement.executeUpdate();
                        }

                        response.sendRedirect("activities.jsp?success=inscripcion");
                    } else {
                        response.sendRedirect("activities.jsp?error=capacidadExcedida");
                    }
                } else {
                    response.sendRedirect("activities.jsp?error=errorConteo");
                }
            }
        } catch (SQLException e) {
            response.sendRedirect("activities.jsp?error=sqlError");
        }
    }
}