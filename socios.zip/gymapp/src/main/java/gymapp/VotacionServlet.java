package gymapp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/voting")
public class VotacionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int actividadId = Integer.parseInt(request.getParameter("activityId"));
        int votacion = Integer.parseInt(request.getParameter("votacion"));
        HttpSession session = request.getSession();
        String usuarioLogin = (String) session.getAttribute("user");

        try (Connection connection = DBConnection.getConnection()) {
            String sql = "UPDATE Participaciones SET votacion = ? WHERE idActividad = ? AND idUsuario = (SELECT id FROM Usuarios WHERE login = ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, votacion);
                statement.setInt(2, actividadId);
                statement.setString(3, usuarioLogin);
                statement.executeUpdate();
            }

            response.sendRedirect("activities.jsp?success=votacion");
        } catch (SQLException e) {
            response.sendRedirect("activities.jsp?error=sqlError");
        }
    }
}