package gymapp;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.logging.Logger;
import java.util.logging.Level;

import javax.servlet.annotation.WebServlet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String username = request.getParameter("login");
        String password = request.getParameter("password");

        LOGGER.info("Intento de inicio de sesi�n: Usuario = " + username);
        
        try (Connection connection = DBConnection.getConnection()) {
            String sql = "SELECT * FROM Usuarios WHERE login = ? AND password = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                statement.setString(2, password);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("user", username);
                    LOGGER.info("Usuario validado con �xito: " + username);
                    response.sendRedirect("activities.jsp");
                } else {
                    LOGGER.warning("Error de inicio de sesi�n: Usuario o contrase�a incorrecta.");
                    response.sendRedirect("index.jsp?error=true");
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error de SQL", e);
            response.sendRedirect("index.jsp?error=sql");
        }
    }
}


