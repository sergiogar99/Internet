package gymapp;

import java.util.Date;

public class Activity {
    private int id;
    private String title;
    private String description;
    private String recomendaciones;
    private String docentes;
    private String dias;
    private String horario;
    private Date fechaInicio;
    private Date fechaFin;

    public Activity() {
    }

    public Activity(int id, String title, String description, String recomendaciones, 
                    String docentes, String dias, String horario, 
                    Date fechaInicio, Date fechaFin) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.recomendaciones = recomendaciones;
        this.docentes = docentes;
        this.dias = dias;
        this.horario = horario;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRecomendaciones() {
        return recomendaciones;
    }

    public void setRecomendaciones(String recomendaciones) {
        this.recomendaciones = recomendaciones;
    }

    public String getDocentes() {
        return docentes;
    }

    public void setDocentes(String docentes) {
        this.docentes = docentes;
    }

    public String getDias() {
        return dias;
    }

    public void setDias(String dias) {
        this.dias = dias;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
}
