CREATE DATABASE gymdb;
USE gymdb;

CREATE TABLE Usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    perfilAcceso VARCHAR(255)
);

CREATE TABLE Actividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT,
    recomendaciones TEXT,
    docentes VARCHAR(255),
    dias VARCHAR(255),
    horario TIME,
    fechaInicio DATE,
    fechaFin DATE
);

CREATE TABLE Ficheros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255),
    ruta VARCHAR(255),
    idActividad INT,
    idUsuario INT,
    FOREIGN KEY (idActividad) REFERENCES Actividades(id),
    FOREIGN KEY (idUsuario) REFERENCES Usuarios(id)
);

CREATE TABLE Participaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idActividad INT,
    idUsuario INT,
    modoPago VARCHAR(255),
    sugerencia TEXT,
    votacion INT,
    comentarios TEXT,
    FOREIGN KEY (idActividad) REFERENCES Actividades(id),
    FOREIGN KEY (idUsuario) REFERENCES Usuarios(id)
);
