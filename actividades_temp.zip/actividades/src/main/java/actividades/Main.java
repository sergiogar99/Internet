package actividades;

import actividades.ActividadDAO;
import actividades.Actividad;

import java.sql.Time;
import java.text.SimpleDateFormat;

public class Main {

    public static void main(String[] args) {
        try {
            // Crear una instancia de SimpleDateFormat para parsear las fechas
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

            // Crear una nueva instancia de Actividad
            Actividad actividad = new Actividad(
                    0, // El ID es autoincremental, as� que aqu� va un placeholder
                    "Yoga para principiantes", // t�tulo
                    "Clases introductorias de Yoga", // descripci�n
                    "Traer ropa c�moda y esterilla", // recomendaciones
                    "Juan P�rez", // docentes
                    "Lunes y Mi�rcoles", // d�as
                    new Time(timeFormat.parse("08:00:00").getTime()), // horario
                    new java.util.Date(dateFormat.parse("2023-01-01").getTime()), // fechaInicio
                    new java.util.Date(dateFormat.parse("2023-06-01").getTime()) // fechaFin
            );

            // Instanciar ActividadDAO y llamar al m�todo insertarActividad
            ActividadDAO actividadDAO = new ActividadDAO();
            boolean resultado = actividadDAO.insertarActividad(actividad);

            // Imprimir resultado de la inserci�n
            if (resultado) {
                System.out.println("Actividad insertada con �xito.");
            } else {
                System.out.println("No se pudo insertar la actividad.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
