package actividades;

import java.sql.Time;
import java.util.Date;

public class Actividad {
    private int id;
    private String titulo;
    private String descripcion;
    private String recomendaciones;
    private String docentes;
    private String dias;
    private Time horario;
    private Date fechaInicio;
    private Date fechaFin;

    // Constructor por defecto
    public Actividad() {
    }

    // Constructor con todos los atributos
    public Actividad(int id, String titulo, String descripcion, String recomendaciones,
                     String docentes, String dias, Time horario, Date fechaInicio, Date fechaFin) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.recomendaciones = recomendaciones;
        this.docentes = docentes;
        this.dias = dias;
        this.horario = horario;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getRecomendaciones() {
        return recomendaciones;
    }

    public void setRecomendaciones(String recomendaciones) {
        this.recomendaciones = recomendaciones;
    }

    public String getDocentes() {
        return docentes;
    }

    public void setDocentes(String docentes) {
        this.docentes = docentes;
    }

    public String getDias() {
        return dias;
    }

    public void setDias(String dias) {
        this.dias = dias;
    }

    public Time getHorario() {
        return horario;
    }

    public void setHorario(Time horario) {
        this.horario = horario;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    // toString() m�todo si necesitas una representaci�n en String de Actividad
    @Override
    public String toString() {
        return "Actividad{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", recomendaciones='" + recomendaciones + '\'' +
                ", docentes='" + docentes + '\'' +
                ", dias='" + dias + '\'' +
                ", horario=" + horario +
                ", fechaInicio=" + fechaInicio +
                ", fechaFin=" + fechaFin +
                '}';
    }
}
