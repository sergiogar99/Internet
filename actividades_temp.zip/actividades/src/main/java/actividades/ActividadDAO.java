package actividades;

import actividades.Actividad;
import actividades.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ActividadDAO {

    public boolean insertarActividad(Actividad actividad) {
        String sql = "INSERT INTO actividades (titulo, descripcion, recomendaciones, docentes, dias, horario, fechaInicio, fechaFin) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, actividad.getTitulo());
            pstmt.setString(2, actividad.getDescripcion());
            pstmt.setString(3, actividad.getRecomendaciones());
            pstmt.setString(4, actividad.getDocentes());
            pstmt.setString(5, actividad.getDias());
            pstmt.setTime(6, actividad.getHorario());
            pstmt.setDate(7, new java.sql.Date(actividad.getFechaInicio().getTime()));
            pstmt.setDate(8, new java.sql.Date(actividad.getFechaFin().getTime()));
            int resultado = pstmt.executeUpdate();
            return resultado > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Actividad obtenerActividadPorId(int id) {
        String sql = "SELECT * FROM actividades WHERE id = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Actividad(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getString("descripcion"),
                        rs.getString("recomendaciones"),
                        rs.getString("docentes"),
                        rs.getString("dias"),
                        rs.getTime("horario"),
                        rs.getDate("fechaInicio"),
                        rs.getDate("fechaFin")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

