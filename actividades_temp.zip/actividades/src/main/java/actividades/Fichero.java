package actividades;

public class Fichero {
    private int id;
    private String titulo;
    private String ruta;
    private int idActividad;

    // Constructor por defecto
    public Fichero() {}

    // Constructor con todos los atributos
    public Fichero(int id, String titulo, String ruta, int idActividad) {
        this.id = id;
        this.titulo = titulo;
        this.ruta = ruta;
        this.idActividad = idActividad;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public int getIdActividad() {
        return idActividad;
    }

    public void setIdActividad(int idActividad) {
        this.idActividad = idActividad;
    }
}

