package actividades;

import actividades.Usuario;
import actividades.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    private static final String INSERT_USUARIO_SQL = "INSERT INTO Usuarios (login, password, perfilAcceso) VALUES (?, ?, ?);";
    private static final String SELECT_USUARIO_BY_ID = "SELECT id, login, password, perfilAcceso FROM Usuarios WHERE id =?";

    public boolean insertarUsuario(Usuario usuario) throws SQLException {
        try (Connection connection = ConexionDB.conectar();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USUARIO_SQL)) {
            preparedStatement.setString(1, usuario.getLogin());
            preparedStatement.setString(2, usuario.getPassword());
            preparedStatement.setString(3, usuario.getPerfilAcceso());
            return preparedStatement.executeUpdate() > 0;
        }
    }

    public Usuario seleccionarUsuario(int id) throws SQLException {
        Usuario usuario = null;
        try (Connection connection = ConexionDB.conectar();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USUARIO_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String login = rs.getString("login");
                String password = rs.getString("password");
                String perfilAcceso = rs.getString("perfilAcceso");
                usuario = new Usuario(id, login, password, perfilAcceso);
            }
        }
        return usuario;
    }

    // M�todos adicionales como actualizarUsuario, eliminarUsuario, seleccionarUsuarios, etc.
}

