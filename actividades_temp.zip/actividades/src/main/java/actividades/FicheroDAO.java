package actividades;

import actividades.Fichero;
import actividades.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FicheroDAO {

    private static final String INSERT_FICHERO_SQL = "INSERT INTO Ficheros (titulo, ruta, idActividad) VALUES (?, ?, ?);";
    private static final String SELECT_FICHERO_BY_ID = "SELECT id, titulo, ruta, idActividad FROM Ficheros WHERE id =?";

    public boolean insertarFichero(Fichero fichero) throws SQLException {
        try (Connection connection = ConexionDB.conectar();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FICHERO_SQL)) {
            preparedStatement.setString(1, fichero.getTitulo());
            preparedStatement.setString(2, fichero.getRuta());
            preparedStatement.setInt(3, fichero.getIdActividad());
            return preparedStatement.executeUpdate() > 0;
        }
    }

    public Fichero seleccionarFichero(int id) throws SQLException {
        Fichero fichero = null;
        try (Connection connection = ConexionDB.conectar();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FICHERO_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String titulo = rs.getString("titulo");
                String ruta = rs.getString("ruta");
                int idActividad = rs.getInt("idActividad");
                fichero = new Fichero(id, titulo, ruta, idActividad);
            }
        }
        return fichero;
    }

    // M�todos adicionales como actualizarFichero, eliminarFichero, seleccionarFicheros, etc.
}

