package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.ActividadDAO;
import DAO.ActividadDAOImpl;
import model.Actividad;

@WebServlet("/CrearEditarActividadServlet")
public class CrearEditarActividadServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ActividadDAO actividadDao = new ActividadDAOImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("crearEditarActividad.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Obtenemos los parámetros del formulario
        String titulo = request.getParameter("titulo");
        String descripcion = request.getParameter("descripcion");
        String recomendaciones = request.getParameter("recomendaciones");
        String docentes = request.getParameter("docentes");
        String dias = request.getParameter("dias");
        String horario = request.getParameter("horario");
        
        Actividad actividad = new Actividad();
        actividad.setTitulo(titulo);
        actividad.setDescripcion(descripcion);
        actividad.setRecomendaciones(recomendaciones);
        actividad.setDocentes(docentes);
        actividad.setDias(dias);

        //Guarda la actividad en la base de datos
        actividadDao.guardarActividad(actividad);

        //Redirige a la página de gestión de actividades
        response.sendRedirect("ActividadesServlet");
    }
}

