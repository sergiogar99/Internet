package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.ActividadDAO;
import DAO.ActividadDAOImpl;
import model.Actividad;

@WebServlet("/ActividadesServlet")
public class ActividadesServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ActividadDAO actividadDao = new ActividadDAOImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Actividad> actividades = actividadDao.obtenerTodasLasActividades();

        request.setAttribute("actividades", actividades);
        RequestDispatcher dispatcher = request.getRequestDispatcher("gestionActividades.jsp");
        dispatcher.forward(request, response);
    }
}


