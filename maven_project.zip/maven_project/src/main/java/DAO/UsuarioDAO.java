package DAO;

public interface UsuarioDAO {
    boolean validarCredenciales(String usuario, String contraseña);
}

