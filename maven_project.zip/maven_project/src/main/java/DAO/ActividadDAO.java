package DAO;

import java.util.List;

import model.Actividad;

public interface ActividadDAO {
    List<Actividad> obtenerTodasLasActividades();
    void guardarActividad(Actividad actividad);
}
