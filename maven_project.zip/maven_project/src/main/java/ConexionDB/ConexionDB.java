package ConexionDB;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class ConexionDB {

    public static Connection obtenerConexion() throws SQLException {
        try {
            Context initialContext = new InitialContext();
            Context envContext = (Context) initialContext.lookup("java:comp/env");

            // El nombre JNDI del recurso JDBC configurado en Glassfish
            String jndiName = "jdbc/Actividades";
            
            DataSource dataSource = (DataSource) envContext.lookup(jndiName);
            return dataSource.getConnection();
        } catch (NamingException e) {
            throw new SQLException("Error al obtener la conexión: " + e.getMessage());
        }
    }
}

