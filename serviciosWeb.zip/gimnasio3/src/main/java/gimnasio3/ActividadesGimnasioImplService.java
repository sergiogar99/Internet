/**
 * ActividadesGimnasioImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gimnasio3;

public interface ActividadesGimnasioImplService extends javax.xml.rpc.Service {
    public java.lang.String getActividadesGimnasioImplPortAddress();

    public gimnasio3.ActividadesGimnasio getActividadesGimnasioImplPort() throws javax.xml.rpc.ServiceException;

    public gimnasio3.ActividadesGimnasio getActividadesGimnasioImplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
