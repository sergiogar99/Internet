package gimnasio3.client;

import gimnasio3.ActividadesGimnasio;
import gimnasio3.ActividadesGimnasioImplService;
import gimnasio3.Actividad;
import java.net.URL;
import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import java.util.Map;

public class GimnasioClient {
    public static void main(String[] args) {
        try {
            QName serviceName = new QName("http://gimnasio3/", "ActividadesGimnasioImplService");
            URL wsdlURL = new URL("http://localhost:8080/gimnasio3/actividades?wsdl");

            Service service = Service.create(wsdlURL, serviceName);
            ActividadesGimnasio port = service.getPort(ActividadesGimnasio.class);

            Map<String, Object> reqContext = ((BindingProvider) port).getRequestContext();
            reqContext.put(BindingProvider.SESSION_MAINTAIN_PROPERTY, true);

            List<Actividad> actividadesConPlazas = port.consultarActividadesConPlazas();
            System.out.println("Actividades con plazas disponibles: " + actividadesConPlazas);

            List<String> historicoConsultas = port.consultar();
            System.out.println("Hist�rico de consultas: " + historicoConsultas);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
