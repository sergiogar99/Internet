package gimnasio3;

import java.time.LocalDateTime;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import gimnasio3.Actividad;

@WebService
public interface ActividadesGimnasio {
    @WebMethod
    List<Actividad> consultarActividadesConPlazas();

    @WebMethod
    List<Actividad> consultarActividadesConPlazasLibres(LocalDateTime fechaInicio, LocalDateTime fechaFin);

    @WebMethod
    Actividad consultarActividadMejorPuntuada();

    @WebMethod
    Actividad consultarActividadMejorPuntuadaEnFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin);

    @WebMethod
    float consultarMediaPuntuacionActividades();

    @WebMethod
    float consultarMediaPuntuacionActividadesEnFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin);

    @WebMethod
    int consultarPlazasLibresActividad(int idActividad);

    @WebMethod
    int consultarNumeroInscritosActividad(int idActividad);

    @WebMethod
    List<String> consultar();
}
