package gimnasio3;

import javax.jws.WebService;
import javax.jws.WebMethod;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.time.LocalDateTime;
import java.util.stream.Collectors;

@WebService(serviceName = "ActividadesGimnasioImplService", endpointInterface = "gimnasio3.ActividadesGimnasio")
public class ActividadesGimnasioImpl implements ActividadesGimnasio {

    private List<Actividad> actividades = new ArrayList<>();
    private List<String> historicoConsultas = new ArrayList<>();

    public ActividadesGimnasioImpl() {
        actividades.add(new Actividad(1, "Yoga", 20, 15, 4.5f, LocalDateTime.now(), LocalDateTime.now().plusHours(2)));
    }

    @WebMethod
    public List<Actividad> consultarActividadesConPlazas() {
        historicoConsultas.add("consultarActividadesConPlazas");
        return actividades;
    }

    @WebMethod
    public List<Actividad> consultarActividadesConPlazasLibres(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        historicoConsultas.add("consultarActividadesConPlazasLibres");
        return actividades.stream()
                .filter(a -> a.getFechaInicio().isAfter(fechaInicio) && a.getFechaFin().isBefore(fechaFin))
                .filter(a -> a.getPlazasOcupadas() < a.getCapacidadTotal())
                .collect(Collectors.toList());
    }

    @WebMethod
    public Actividad consultarActividadMejorPuntuada() {
        historicoConsultas.add("consultarActividadMejorPuntuada");
        return actividades.stream()
                .max(Comparator.comparing(Actividad::getPuntuacion))
                .orElse(null);
    }

    @WebMethod
    public Actividad consultarActividadMejorPuntuadaEnFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        historicoConsultas.add("consultarActividadMejorPuntuadaEnFechas");
        return actividades.stream()
                .filter(a -> a.getFechaInicio().isAfter(fechaInicio) && a.getFechaFin().isBefore(fechaFin))
                .max(Comparator.comparing(Actividad::getPuntuacion))
                .orElse(null);
    }

    @WebMethod
    public float consultarMediaPuntuacionActividades() {
        historicoConsultas.add("consultarMediaPuntuacionActividades");
        return (float) actividades.stream()
                                  .mapToDouble(Actividad::getPuntuacion)
                                  .average()
                                  .orElse(0.0);
    }

    @WebMethod
    public float consultarMediaPuntuacionActividadesEnFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        historicoConsultas.add("consultarMediaPuntuacionActividadesEnFechas");
        return (float) actividades.stream()
                                  .filter(a -> a.getFechaInicio().isAfter(fechaInicio) && a.getFechaFin().isBefore(fechaFin))
                                  .mapToDouble(Actividad::getPuntuacion)
                                  .average()
                                  .orElse(0.0);
    }

    @WebMethod
    public int consultarPlazasLibresActividad(int idActividad) {
        historicoConsultas.add("consultarPlazasLibresActividad");
        return actividades.stream()
                .filter(a -> a.getId() == idActividad)
                .findFirst()
                .map(a -> a.getCapacidadTotal() - a.getPlazasOcupadas())
                .orElse(0);
    }

    @WebMethod
    public int consultarNumeroInscritosActividad(int idActividad) {
        historicoConsultas.add("consultarNumeroInscritosActividad");
        return actividades.stream()
                .filter(a -> a.getId() == idActividad)
                .findFirst()
                .map(Actividad::getPlazasOcupadas)
                .orElse(0);
    }

    @WebMethod
    public List<String> consultar() {
        return historicoConsultas;
    }
    
}
