package gimnasio3;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Actividad implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String nombre;
    private int capacidadTotal;
    private int plazasOcupadas;
    private float puntuacion;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;

    public Actividad() {
    }

    public Actividad(int id, String nombre, int capacidadTotal, int plazasOcupadas, float puntuacion,
                     LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        this.id = id;
        this.nombre = nombre;
        this.capacidadTotal = capacidadTotal;
        this.plazasOcupadas = plazasOcupadas;
        this.puntuacion = puntuacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidadTotal() {
        return capacidadTotal;
    }

    public void setCapacidadTotal(int capacidadTotal) {
        this.capacidadTotal = capacidadTotal;
    }

    public int getPlazasOcupadas() {
        return plazasOcupadas;
    }

    public void setPlazasOcupadas(int plazasOcupadas) {
        this.plazasOcupadas = plazasOcupadas;
    }

    public float getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(float puntuacion) {
        this.puntuacion = puntuacion;
    }

    public LocalDateTime getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDateTime fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDateTime getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDateTime fechaFin) {
        this.fechaFin = fechaFin;
    }

    @Override
    public String toString() {
        return "Actividad{" +
            "id=" + id +
            ", nombre='" + nombre + '\'' +
            ", capacidadTotal=" + capacidadTotal +
            ", plazasOcupadas=" + plazasOcupadas +
            ", puntuacion=" + puntuacion +
            ", fechaInicio=" + fechaInicio +
            ", fechaFin=" + fechaFin +
            '}';
    }
}
