package gimnasio3;

public class ActividadesGimnasioProxy implements gimnasio3.ActividadesGimnasio {
  private String _endpoint = null;
  private gimnasio3.ActividadesGimnasio actividadesGimnasio = null;
  
  public ActividadesGimnasioProxy() {
    _initActividadesGimnasioProxy();
  }
  
  public ActividadesGimnasioProxy(String endpoint) {
    _endpoint = endpoint;
    _initActividadesGimnasioProxy();
  }
  
  private void _initActividadesGimnasioProxy() {
    try {
      actividadesGimnasio = (new gimnasio3.ActividadesGimnasioImplServiceLocator()).getActividadesGimnasioImplPort();
      if (actividadesGimnasio != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)actividadesGimnasio)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)actividadesGimnasio)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (actividadesGimnasio != null)
      ((javax.xml.rpc.Stub)actividadesGimnasio)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public gimnasio3.ActividadesGimnasio getActividadesGimnasio() {
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio;
  }
  
  public java.util.List consultarActividadesConPlazas(){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarActividadesConPlazas();
  }
  
  public java.util.List consultarActividadesConPlazasLibres(java.time.LocalDateTime fechaInicio, java.time.LocalDateTime fechaFin){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarActividadesConPlazasLibres(fechaInicio, fechaFin);
  }
  
  public gimnasio3.Actividad consultarActividadMejorPuntuada(){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarActividadMejorPuntuada();
  }
  
  public gimnasio3.Actividad consultarActividadMejorPuntuadaEnFechas(java.time.LocalDateTime fechaInicio, java.time.LocalDateTime fechaFin){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarActividadMejorPuntuadaEnFechas(fechaInicio, fechaFin);
  }
  
  public float consultarMediaPuntuacionActividades(){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarMediaPuntuacionActividades();
  }
  
  public float consultarMediaPuntuacionActividadesEnFechas(java.time.LocalDateTime fechaInicio, java.time.LocalDateTime fechaFin){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarMediaPuntuacionActividadesEnFechas(fechaInicio, fechaFin);
  }
  
  public int consultarPlazasLibresActividad(int idActividad){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarPlazasLibresActividad(idActividad);
  }
  
  public int consultarNumeroInscritosActividad(int idActividad){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultarNumeroInscritosActividad(idActividad);
  }
  
  public java.util.List consultar(){
    if (actividadesGimnasio == null)
      _initActividadesGimnasioProxy();
    return actividadesGimnasio.consultar();
  }
  
  
}